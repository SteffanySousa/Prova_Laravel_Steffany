<?php

interface Emitir
{
    public function registrar();
   
}