<?php

class Propriedade extends Certidao
{

    final public function registar()
    {
        echo 'A certidão de ' .$this->tipoCertidaoo .' foi registrada';
    }

}