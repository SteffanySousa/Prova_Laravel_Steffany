<?php

class Registro 
{
    private $numeroRegistro;
    private $dataRegistro;

    public function __construct ()
    {
    $this->numeroResgistro=$numeroResgistro;
    $this->dataRegistro= $dataRegistro;
    }
    public function registrar($numeroRegistro, $dataRegistro, $nomeTabeliao, $nomeCartorio)
    {
        
    }

}